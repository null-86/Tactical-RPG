Disclaimer: 
This is an early pre-alpha build of a project I've been working on in my limited free time. There will be bugs in this build. 
I have not had this issue in a
"Alt + F4" will shut down the game if an unhandled error occurs. 

Most art assets are public domain courtesy of www.kenney.nl. 

The UI is very basic; there are systems which provide minimal feedback right now but which are active behind the scenes. A couple Examples include Inventory, Weight - stamina regen interactions, unit and weapon classes and abilities ("Redacted" has a weapon with an "Instakill" ability), etc.